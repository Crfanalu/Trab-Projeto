<?php

try{
    $banco = new PDO("sqlite:banco.sqlite");
    echo "Banco conectado!";

}catch(PDOException $e){
    echo "Deu erro na conexão!";
    echo $e->getMessage();
}

$Tabela = "CREATE TABLE IF NOT EXISTS Bebida(NomeBebida TEXT, TipoBebida TEXT, SaborBebida TEXT, TeorAlcoolicoBebida TEXT, PaisOrigemBebida TEXT, primary key(NomeBebida))";

$banco->exec($Tabela);