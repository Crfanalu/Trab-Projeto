<?php
require "Bebida.php";
require "Conexao.php";
require "RepositorioBebida.php";
$Bebida = new Bebida('Império', 'Cerveja', 'Pilsen', '4,5%', 'Brasileira');

$repBebida= New RepositorioBebida();

$Bebida2 = New Bebida('Heineken', 'Cerveja', 'Armagor Leve', '5,6%', 'Holandesa');
$Bebida3 = New Bebida('Dell Vale', 'Suco', 'Uva', 'o,o%', 'México');

$repBebida->cadastrar($banco,$Bebida1);
$repBebida->cadastrar($banco,$Bebida2);
$repBebida->cadastrar($banco,$Bebida3);


$banco->query($Tabela);

